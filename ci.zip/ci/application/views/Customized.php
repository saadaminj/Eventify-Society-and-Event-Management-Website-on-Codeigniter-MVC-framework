<!DOCTYPE html>
<html>
<head>
	<title>Customized Webpage for About us</title>
</head>
<body>
<h1>IN ABOUT US PAGE</h1>
<p>HELLO WORLD</p>
</body>
</html>