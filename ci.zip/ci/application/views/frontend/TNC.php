<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About THINK AND CREATE</h1>
					<h3>Mission</h3>
							<p>Think N Create is the society which has the following goals to accomplish in future:</p>
							
								<li>It introduces innovative culture at NUCES-FAST University.</li>
								<li>It focuses on the events that will encourage different creative ideas.</li>
								<li> It provokes the environment of thinking and creating different projects based on unique ideas.</li>
								<li>It brings the latest development of the modern world more closer to the students.</li>
								<li>It provides the complete package in the advancement of the upcoming technology.</li>
								<li>It organizes different workshops and seminars to enhance the abilities of the students</li>
							</P>
							<br>
							<h4>Founded in 2009</h4>
							
				</div>
			</div>
			</div>
			
		</div>
	</div>
	