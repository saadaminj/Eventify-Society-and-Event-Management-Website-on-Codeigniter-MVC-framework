<div id="fh5co-contact" style="text-align: center;" >
		<div class="container">
			<div class="row">
				
				<div class="col-md-12 animate-box">
					<div class="price-box">
					<h1 >ALERT</h1>


                   	<br><br><br>
                   	<h4><?php 
                   	echo "Oops Something went wrong" ;
                   	?>
                   	</h4>
					</ul>
				</div>
			</div>
			</div>
			
		</div>
	</div>
	