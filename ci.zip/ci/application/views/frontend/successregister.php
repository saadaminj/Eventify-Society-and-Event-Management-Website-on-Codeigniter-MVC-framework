<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					
					
				</div>
				<div class="col-md-12 animate-box">
					<div class="price-box">
					<h3>Congratulations you have been successfully registered</h3>
				
							
							
				</div>
			</div>
			</div>
			
		</div>
	</div>
	