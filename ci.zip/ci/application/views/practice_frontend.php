<!DOCTYPE html>
<html>
<head>
	<?= link_tag('assets/styling.css') ?>
	<title>WELCOME</title>
</head>
<body>
<h1 class="ABC">Recieving from Models</h1>
<?php
print_r($value);
?>
</body>
</html>